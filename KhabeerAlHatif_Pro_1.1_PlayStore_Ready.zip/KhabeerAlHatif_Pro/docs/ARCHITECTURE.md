# المعمارية

## Android
- Compose UI
- ViewModel
- Retrofit
- RTL Arabic
- طبقة API منفصلة

## Server
- Express
- OpenAI Responses API
- مفتاح API في متغير بيئة فقط
- fallback محلي عند غياب المفتاح

## التوسعة القادمة
1. قاعدة بيانات أعطال JSON/SQLite/Backend
2. صور القطع والمخططات
3. رفع صورة اللوحة للتحليل
4. حساب المستخدم والمزامنة
5. سجل التشخيص
6. نظام اشتراك/حصة استخدام
7. Analytics مع احترام الخصوصية
8. اختبارات نشر Play Store
