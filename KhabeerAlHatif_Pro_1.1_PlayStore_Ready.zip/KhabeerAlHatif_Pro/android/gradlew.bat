@echo off
rem Generate/download Gradle wrapper from Android Studio if needed.
