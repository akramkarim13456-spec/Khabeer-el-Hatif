package dz.khabeeralhatif.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

data class DiagnoseRequest(
    val message: String,
    val history: List<ChatItem> = emptyList(),
    val device: Map<String,String> = emptyMap()
)
data class ChatItem(val role:String, val text:String)
data class Question(val text:String, val options:List<String> = emptyList())
data class Diagnosis(val name:String, val probability:Int, val reason:String, val nextTest:String)
data class DiagnoseResponse(
    val status:String = "question",
    val message:String = "",
    val question:Question? = null,
    val diagnoses:List<Diagnosis> = emptyList(),
    val steps:List<String> = emptyList(),
    val tools:List<String> = emptyList(),
    val difficulty:String = "مبتدئ"
)

interface Api {
    @POST("api/diagnose")
    suspend fun diagnose(@Body body:DiagnoseRequest):DiagnoseResponse
}

class MainViewModel: ViewModel() {
    var serverUrl by mutableStateOf("http://10.0.2.2:8080/")
    var messages by mutableStateOf(listOf<ChatItem>())
    var response by mutableStateOf<DiagnoseResponse?>(null)
    var loading by mutableStateOf(false)

    private fun api(): Api = Retrofit.Builder()
        .baseUrl(if (serverUrl.endsWith("/")) serverUrl else "$serverUrl/")
        .addConverterFactory(GsonConverterFactory.create())
        .build().create(Api::class.java)

    fun send(text:String) {
        if (text.isBlank()) return
        messages = messages + ChatItem("user", text)
        loading = true
        viewModelScope.launch {
            try {
                val r = api().diagnose(DiagnoseRequest(text, messages))
                response = r
                messages = messages + ChatItem("assistant", r.message)
            } catch (e:Exception) {
                response = DiagnoseResponse(
                    status="question",
                    message="تعذر الاتصال بالخادم. تأكد من عنوان الخادم ثم أعد المحاولة.",
                    question=Question("ما نوع العطل؟", listOf("لا يشتغل","لا يشحن","شاشة سوداء","يسخن"))
                )
            } finally { loading = false }
        }
    }
}

@Composable
fun App(vm:MainViewModel = viewModel()) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme {
            Scaffold(
                topBar = { TopAppBar(title={Text("خبير الهاتف 🔧")}) }
            ) { pad ->
                LazyColumn(
                    modifier=Modifier.fillMaxSize().padding(pad).padding(16.dp),
                    verticalArrangement=Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text("من الصفر إلى الاحتراف", fontSize=20.sp)
                        Text("تشخيص ذكي + تعلم + أدوات + اختبارات", color=MaterialTheme.colorScheme.primary)
                    }
                    item {
                        OutlinedTextField(
                            value=vm.serverUrl,
                            onValueChange={vm.serverUrl=it},
                            label={Text("عنوان خادم الذكاء الاصطناعي")},
                            modifier=Modifier.fillMaxWidth()
                        )
                    }
                    items(vm.messages) { m ->
                        Card(Modifier.fillMaxWidth()) {
                            Text(
                                if (m.role=="user") "أنت: ${m.text}" else "خبير الهاتف: ${m.text}",
                                modifier=Modifier.padding(14.dp)
                            )
                        }
                    }
                    item {
                        var input by remember { mutableStateOf("") }
                        OutlinedTextField(
                            value=input,
                            onValueChange={input=it},
                            label={Text("صف عطل الهاتف...")},
                            modifier=Modifier.fillMaxWidth(),
                            minLines=3
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick={ val x=input; input=""; vm.send(x) },
                            enabled=!vm.loading,
                            modifier=Modifier.fillMaxWidth()
                        ) { Text(if(vm.loading) "جارٍ التحليل..." else "بدء التشخيص 🔍") }
                    }
                    vm.response?.let { r ->
                        item {
                            if (r.question != null) {
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(14.dp)) {
                                        Text(r.question.text, fontSize=17.sp)
                                        Spacer(Modifier.height(8.dp))
                                        r.question.options.forEach { opt ->
                                            OutlinedButton(
                                                onClick={vm.send(opt)},
                                                modifier=Modifier.fillMaxWidth().padding(vertical=3.dp)
                                            ){ Text(opt) }
                                        }
                                    }
                                }
                            }
                            if (r.diagnoses.isNotEmpty()) {
                                Text("الاحتمالات", fontSize=18.sp)
                                r.diagnoses.forEach { d ->
                                    Card(Modifier.fillMaxWidth()) {
                                        Column(Modifier.padding(12.dp)) {
                                            Text("${d.name} — ${d.probability}%")
                                            Text(d.reason)
                                            Text("الفحص التالي: ${d.nextTest}")
                                        }
                                    }
                                }
                            }
                            if (r.steps.isNotEmpty()) {
                                Text("خطوات الفحص", fontSize=18.sp)
                                r.steps.forEach { Text("• $it") }
                            }
                            if (r.tools.isNotEmpty()) {
                                Text("الأدوات: ${r.tools.joinToString("، ")}")
                            }
                        }
                    }
                    item {
                        Divider()
                        Text("📚 التعلم: 10 مستويات")
                        Text("🔧 الأدوات والفحوصات")
                        Text("📝 الاختبارات والتقدم")
                        Text("🖼️ الصور والمخططات — جاهزة للإضافة")
                    }
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}
