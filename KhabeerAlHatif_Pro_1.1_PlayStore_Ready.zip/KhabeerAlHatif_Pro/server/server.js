import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();

const app = express();
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || "*" }));
app.use(express.json({ limit: "2mb" }));

const port = Number(process.env.PORT || 8080);
const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

const SYSTEM = `
أنت "خبير الهاتف"، مساعد عربي متخصص في تشخيص أعطال الهواتف وتدريب فنيي الصيانة.
أجب بالعربية الواضحة. لا تدّعي أن التشخيص مؤكد من دون قياس أو فحص.
رتّب الاحتمالات، اطرح سؤال متابعة واحداً فقط في كل دورة، وابدأ بالفحوص الآمنة وغير المكلفة.
لا تعط تعليمات قد تسبب صعقاً أو حريقاً أو تلفاً إضافياً. عند الحاجة لفك الهاتف أو القياس على اللوحة، اذكر أن ذلك للفني المتمرس.
أخرج JSON فقط بهذا الشكل:
{
 "status":"question|diagnosis",
 "message":"رسالة قصيرة للمستخدم",
 "question":null أو {"text":"...","options":["...","..."]},
 "diagnoses":[{"name":"...","probability":0,"reason":"...","nextTest":"..."}],
 "steps":["..."],
 "tools":["..."],
 "difficulty":"مبتدئ|متوسط|متقدم"
}
`;

function localDiagnosis(text) {
  const t = text.toLowerCase();
  if (/(لا يشحن|ما يشحن|الشحن|charging)/i.test(t)) {
    return {
      status:"question",
      message:"سنحدد سبب مشكلة الشحن خطوة بخطوة.",
      question:{text:"عند توصيل الشاحن، هل تظهر علامة الشحن أو نسبة البطارية؟",options:["نعم","لا","تظهر وتختفي"]},
      diagnoses:[],
      steps:["جرّب كابل وشاحن موثوقين قبل فتح الهاتف.","افحص منفذ USB-C بصرياً من دون إدخال معدن."],
      tools:["كابل وشاحن سليم","مصباح فحص"],
      difficulty:"مبتدئ"
    };
  }
  if (/(لا يشتغل|ما يشتغل|لا يعمل|ميت|black screen)/i.test(t)) {
    return {
      status:"question",
      message:"سنفصل بين مشكلة الطاقة ومشكلة الشاشة.",
      question:{text:"هل يهتز الهاتف أو يصدر صوتاً عند الضغط على زر التشغيل؟",options:["نعم","لا","لا أعرف"]},
      diagnoses:[],
      steps:["اشحن الهاتف 20 دقيقة بشاحن سليم.","جرّب إعادة التشغيل القسري حسب طراز الهاتف."],
      tools:["شاحن سليم"],
      difficulty:"مبتدئ"
    };
  }
  if (/(شاشة سوداء|لا توجد صورة|no display)/i.test(t)) {
    return {
      status:"question",
      message:"قد تكون المشكلة في الشاشة أو الإضاءة أو مسار الصورة.",
      question:{text:"هل الهاتف يستقبل مكالمات أو يهتز رغم عدم وجود صورة؟",options:["نعم","لا","غير متأكد"]},
      diagnoses:[],
      steps:["اختبر الهاتف في مكان مضاء ولا تضغط على الشاشة بقوة.","إذا كان الهاتف يعمل والصورة غائبة، يحتاج الفحص المتقدم إلى فني."],
      tools:["مصباح فحص"],
      difficulty:"متوسط"
    };
  }
  return {
    status:"question",
    message:"أحتاج بعض التفاصيل قبل ترجيح العطل.",
    question:{text:"ما الذي يحدث بالضبط؟",options:["لا يشتغل","لا يشحن","شاشة سوداء","يسخن","يطفئ نفسه","مشكلة أخرى"]},
    diagnoses:[],
    steps:["اذكر موديل الهاتف وما حدث قبل ظهور العطل، مثل سقوط أو ماء أو تغيير قطعة."],
    tools:[],
    difficulty:"مبتدئ"
  };
}

app.get("/health", (_req,res)=>res.json({ok:true, service:"KhabeerAlHatif AI"}));

app.post("/api/diagnose", async (req,res)=>{
  const { message, history = [], device = {} } = req.body || {};
  if (!message || typeof message !== "string") {
    return res.status(400).json({error:"message is required"});
  }

  if (!client) return res.json(localDiagnosis(message));

  const context = JSON.stringify({ device, history, current: message });
  try {
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6-luna",
      instructions: SYSTEM,
      input: context
    });

    let raw = response.output_text || "";
    raw = raw.replace(/^```json\s*/i,"").replace(/```$/,"").trim();
    const data = JSON.parse(raw);
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(502).json({
      status:"question",
      message:"تعذر الوصول إلى محرك الذكاء الاصطناعي الآن. سأستخدم التشخيص المحلي.",
      ...localDiagnosis(message)
    });
  }
});

app.listen(port, ()=>console.log(`KhabeerAlHatif server listening on :${port}`));
