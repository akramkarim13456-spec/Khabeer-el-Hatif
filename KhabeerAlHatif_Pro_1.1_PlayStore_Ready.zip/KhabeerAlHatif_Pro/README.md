# خبير الهاتف — Pro 1.0

تطبيق Android عربي RTL للتعلم من الصفر إلى الاحتراف وتشخيص أعطال الهواتف.

## المكونات
- Android Studio / Kotlin / Jetpack Compose
- تشخيص محلي سريع يعمل بدون إنترنت لبعض الأعطال الشائعة
- تشخيص AI حقيقي عبر خادم وسيط
- قاعدة أعطال قابلة للتوسعة
- وضع التعلم: 10 مستويات
- أدوات الفني
- اختبارات وتقدم
- بنية جاهزة لإضافة الصور والمخططات لاحقاً
- لا يوجد مفتاح API داخل APK

## تشغيل Android
1. افتح مجلد `android` في Android Studio.
2. انتظر Gradle Sync.
3. شغّل التطبيق على هاتف أو محاكي.
4. من الإعدادات ضع عنوان الخادم، مثلاً:
   `http://10.0.2.2:8080`
   للمحاكي Android Emulator.
5. على هاتف حقيقي استخدم عنوان IP للحاسوب على الشبكة المحلية أثناء الاختبار.

## تشغيل الخادم
Node.js 20+:
```bash
cd server
npm install
cp .env.example .env
# ضع OPENAI_API_KEY في .env
npm start
```

الخادم يستخدم Responses API من OpenAI ولا يضع المفتاح داخل التطبيق.

## النشر
بعد الاختبار:
- Android Studio > Build > Generate Signed App Bundle
- اختر AAB
- أنشئ حساب/تطبيق Google Play Console
- ارفع ملف AAB وأكمل بيانات المتجر واختبارات Google Play.

> النسخة المرفقة هي مشروع مصدر قابل للبناء والتطوير، وليست ملف AAB موقعاً للنشر مباشرة.


## النشر السحابي
يوجد `render.yaml` و`server/Dockerfile` و`DEPLOYMENT_AR.md` لتشغيل الخادم على Render.
عنوان HTTPS النهائي لا يمكن تحديده قبل إنشاء Web Service في حساب الاستضافة؛ المنصة تنشئه تلقائياً.

## Google Play
يوجد `PLAY_STORE_LISTING_AR.md` و`PRIVACY_POLICY_AR.md` كمواد أولية لصفحة المتجر.
