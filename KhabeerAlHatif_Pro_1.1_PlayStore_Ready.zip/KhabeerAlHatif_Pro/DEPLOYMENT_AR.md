# تشغيل خادم خبير الهاتف — Render

## 1) أنشئ مستودع GitHub
ارفع محتويات المشروع إلى مستودع جديد، مثلاً:
`khabeer-alhatif`

## 2) أنشئ Web Service على Render
اختر New > Web Service ثم اربط مستودع GitHub.

الإعدادات:
- Root Directory: اتركه فارغاً
- Runtime: Docker
- Dockerfile Path: `server/Dockerfile`
- Docker Context: `server`
- Health Check Path: `/health`

## 3) متغيرات البيئة
أضف:
- `OPENAI_API_KEY` = مفتاح API الخاص بك
- `OPENAI_MODEL` = نموذج متاح في حسابك
- `ALLOWED_ORIGIN` = `*` للاختبار

بعد النشر سيعطي Render عنواناً شبيهاً:
`https://khabeer-alhatif-api.onrender.com`

هذا العنوان هو الذي يوضع داخل التطبيق في خانة:
«عنوان خادم الذكاء الاصطناعي».

## 4) مهم
لا تضع OPENAI_API_KEY داخل Android أو GitHub.
ضعه فقط في Environment Variables في Render.

## 5) اختبار الخادم
افتح:
`https://YOUR-SERVICE.onrender.com/health`

يجب أن تحصل على JSON مثل:
`{"ok":true,"service":"KhabeerAlHatif AI"}`

ثم جرّب التطبيق بعنوان:
`https://YOUR-SERVICE.onrender.com/`

## بديل
يمكن استخدام Railway أو Fly.io أو خادم VPS. نفس مبدأ التشغيل ينطبق: Node.js + متغيرات بيئة + HTTPS.

## ملاحظة عن عنوان الخادم
لا يمكن إنشاء عنوان Render فعلي من داخل ChatGPT لأن إنشاء الخدمة يحتاج إلى حساب الاستضافة وملكية المستخدم. بعد إنشاء الخدمة، العنوان الذي تمنحه المنصة هو العنوان الصحيح للتطبيق.
